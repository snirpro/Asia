import {inject, Injectable} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class OrdersService {
  httpClient = inject(HttpClient);
  private baseUrl = 'http://localhost:3000'; // Your API base URL
  constructor() { }
  // Create a new order
  createOrder(orderData: any): Observable<any> {
    return this.httpClient.post(`${this.baseUrl}/reservations`, orderData);
  }

  // Retrieve all orders
  getAllOrders(): Observable<any[]> {
    return this.httpClient.get<any[]>(`${this.baseUrl}/reservations`);
  }

  // Delete an order
  deleteOrder(orderId: number): Observable<any> {
    return this.httpClient.delete(`${this.baseUrl}/reservations/${orderId}`);
  }
}
