import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { inject } from '@angular/core';
import {catchError, map, tap} from 'rxjs/operators';
import {Observable, of} from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  httpClient = inject(HttpClient);
  baseUrl = 'http://localhost:3000';
  constructor() { }
  signup(data: any) {
    return this.httpClient.post(`${this.baseUrl}/register`, data);
  }
  login(data: any) {
    return this.httpClient.post(`${this.baseUrl}/login`, data)
      .pipe(tap((result) => {
        localStorage.setItem('authUser', JSON.stringify(result));
      }));
  }
  logout() {
    localStorage.removeItem('authUser');
  }
  isLoggedIn() {
    return localStorage.getItem('authUser') !== null;
  }
  isAdmin(): boolean {
    const user = JSON.parse(localStorage.getItem('authUser') || '{}');
    return user.isAdmin || false;  // Assuming isAdmin is a boolean stored in localStorage
  }

  getUserId(): number | undefined {
    const user = JSON.parse(localStorage.getItem('authUser') || '{}');
    return user.userId;  // Ensure 'userId' is stored during the login process
  }

}
