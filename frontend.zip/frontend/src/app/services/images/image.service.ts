import {inject, Injectable} from '@angular/core';
import {HttpClient} from "@angular/common/http";
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ImageService {
  httpClient = inject(HttpClient);
  private baseUrl = 'http://localhost:3000'; // Your API base URL
  constructor() { }
  uploadImage(imageData: any): Observable<any> {
    return this.httpClient.post(`${this.baseUrl}/photos`, imageData);
  }
  getAllImages(): Observable<any[]> {
    return this.httpClient.get<any[]>(`${this.baseUrl}/photos`);
  }
  deleteImage(imageId: number): Observable<any> {
    return this.httpClient.delete(`${this.baseUrl}/photos/${imageId}`);
  }
}
