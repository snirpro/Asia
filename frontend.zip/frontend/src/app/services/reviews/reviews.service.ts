import {inject, Injectable} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ReviewsService {
  httpClient = inject(HttpClient);
  private baseUrl = 'http://localhost:3000';  // URL to web API

  constructor() { }

  // Function to post a new review
  postReview(data: any): Observable<any> {
    return this.httpClient.post(`${this.baseUrl}/reviews`, data);
  }
  // Function to fetch all reviews
  getReviews(): Observable<any[]> {
    return this.httpClient.get<any[]>(`${this.baseUrl}/reviews`);
  }

  // Function to delete a review (admin only)
  deleteReview(reviewId: number): Observable<any> {
    return this.httpClient.delete(`${this.baseUrl}/reviews/${reviewId}`);
  }
}
