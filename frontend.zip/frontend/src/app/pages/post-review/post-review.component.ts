import { Component,inject } from '@angular/core';
import {FormGroup, FormControl, Validators, ReactiveFormsModule} from '@angular/forms';
import { ReviewsService } from '../../services/reviews/reviews.service';
import {AuthService} from "../../services/auth/auth.service";
import { Router, RouterModule } from '@angular/router';
@Component({
  selector: 'app-post-review',
  standalone: true,
  imports: [
    ReactiveFormsModule,RouterModule
  ],
  templateUrl: './post-review.component.html',
  styleUrl: './post-review.component.css'
})

export class PostReviewComponent  {
  authService  =  inject(AuthService);
  router  =  inject(Router);
  reviewService  =  inject(ReviewsService);


  public reviewForm = new FormGroup({
    user_id: new FormControl(this.authService.getUserId(), [Validators.required]),
    review: new FormControl('', [Validators.required]),
    rating: new FormControl('', [Validators.required, Validators.min(1), Validators.max(5)]),
  })
  public submitReview() {
    if (this.reviewForm.valid) {
      this.reviewService.postReview(this.reviewForm.value)
        .subscribe({
          next: (data: any) => {
            this.router.navigate(['/reviews']);
          },
          error: (err) => console.log(err)
        });
    }
  }
}
