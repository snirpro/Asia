import {Component, inject, OnInit} from '@angular/core';
import { ReviewsService } from '../../services/reviews/reviews.service';
import { AuthService } from '../../services/auth/auth.service';
import {NgForOf, NgIf, NgOptimizedImage} from "@angular/common";
import {RouterLink, RouterLinkActive} from "@angular/router";
@Component({
  selector: 'app-reviews',
  standalone: true,
  imports: [
    NgForOf,
    NgIf,
    RouterLink,
    RouterLinkActive,
    NgOptimizedImage
  ],
  templateUrl: './reviews.component.html',
  styleUrl: './reviews.component.css'
})
export class ReviewsComponent implements OnInit{
  authService = inject(AuthService);
  reviews: any[] = [];

  constructor(private reviewsService: ReviewsService) {}

  ngOnInit() {
    this.loadReviews();
  }

  loadReviews() {
    this.reviewsService.getReviews().subscribe({
      next: (data) => {
        this.reviews = data;
      },
      error: (error) => {
        console.error('Failed to load reviews', error);
      }
    });
  }

  deleteReview(reviewId: number) {
    this.reviewsService.deleteReview(reviewId).subscribe({
      next: () => {
        console.log('Review deleted successfully');
        this.loadReviews(); // Reload reviews after deleting
      },
      error: (error) => {
        console.error('Failed to delete review', error);
      }
    });
  }

  protected readonly alert = alert;
}

