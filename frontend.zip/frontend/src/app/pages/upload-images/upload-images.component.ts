import { Component,inject } from '@angular/core';
import {FormGroup, FormControl, Validators, ReactiveFormsModule, FormsModule} from '@angular/forms';
import { ImageService } from '../../services/images/image.service';
import {AuthService} from "../../services/auth/auth.service";
import { Router, RouterModule } from '@angular/router';
@Component({
  selector: 'app-upload-images',
  standalone: true,
  imports: [
    FormsModule,
    ReactiveFormsModule
  ],
  templateUrl: './upload-images.component.html',
  styleUrl: './upload-images.component.css'
})
export class UploadImagesComponent {
  authService  =  inject(AuthService);
  router  =  inject(Router);
  imageService  =  inject(ImageService);

  public imageForm = new FormGroup({
    Picture_classification: new FormControl('', [Validators.required]),
    photo_url: new FormControl('', [Validators.required]),
  })

  public submitImage() {
    if (this.imageForm.valid) {
      this.imageService.uploadImage(this.imageForm.value)
        .subscribe({
          next: (data: any) => {
            this.router.navigate(['/pictures']);
          },
          error: (err) => console.log(err)
        });
    }
  }

}
