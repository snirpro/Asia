import {Component, inject, OnInit} from '@angular/core';
import {FormGroup, FormControl, Validators, ReactiveFormsModule} from '@angular/forms';
import { OrdersService } from '../../services/orders/orders.service';
import { AuthService } from "../../services/auth/auth.service";
import { Router } from "@angular/router";

@Component({
  selector: 'app-make-order',
  standalone: true,
  imports: [
    ReactiveFormsModule
  ],
  templateUrl: './make-order.component.html',
  styleUrl: './make-order.component.css'
})
export class MakeOrderComponent {
  authService  =  inject(AuthService);
  router  =  inject(Router);
  ordersService  =  inject(OrdersService);

  public ordersForm = new FormGroup({
    user_id: new FormControl(this.authService.getUserId(), [Validators.required]),
    first_name: new FormControl('', [Validators.required]),
    last_name: new FormControl('', [Validators.required]),
    phone_number: new FormControl('', [Validators.required]),
    id_number: new FormControl('', [Validators.required]),
    number_of_guests: new FormControl('', [Validators.required, Validators.min(2), Validators.max(6)]),
    entry_date: new FormControl('',[Validators.required]),
    exit_date: new FormControl('', [Validators.required]),
    payment_type: new FormControl('credit', [Validators.required]),
    credit_card_number: new FormControl('', [Validators.required]),
    card_validity: new FormControl('', [Validators.required]),
    cvv: new FormControl('', [Validators.required])
  })
  public submitReview() {
    if (this.ordersForm.valid) {
      this.ordersService.createOrder(this.ordersForm.value)
        .subscribe({
          next: (data: any) => {
            this.router.navigate(['/home']);
          },
          error: (err) => console.log(err)
        });
    }
  }
}
