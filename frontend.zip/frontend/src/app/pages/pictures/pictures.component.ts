import {Component, inject, OnInit} from '@angular/core';
import { ImageService } from '../../services/images/image.service';
import { AuthService } from '../../services/auth/auth.service';
import {NgForOf, NgIf, NgOptimizedImage} from "@angular/common";
import {RouterLink, RouterLinkActive} from "@angular/router";
@Component({
  selector: 'app-pictures',
  standalone: true,
  imports: [
    NgOptimizedImage,
    NgForOf,
    NgIf,
    RouterLink,
    RouterLinkActive
  ],
  templateUrl: './pictures.component.html',
  styleUrl: './pictures.component.css'
})
export class PicturesComponent {
  authService = inject(AuthService);
  Images: any[] = [];

  constructor(private imageService: ImageService) {}

  ngOnInit() {
    this.loadImages();
  }

  loadImages() {
    this.imageService.getAllImages().subscribe({
      next: (data) => {
        this.Images = data;
      },
      error: (error) => {
        console.error('Failed to load Images', error);
      }
    });
  }

  deleteImage(imageId: number) {
    this.imageService.deleteImage(imageId).subscribe({
      next: () => {
        console.log('Image deleted successfully');
        this.loadImages(); // Reload reviews after deleting
      },
      error: (error) => {
        console.error('Failed to delete image', error);
      }
    });
  }

  protected readonly alert = alert;
}
