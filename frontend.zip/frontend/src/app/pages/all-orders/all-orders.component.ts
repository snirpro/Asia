import {Component, inject, OnInit} from '@angular/core';
import { OrdersService } from '../../services/orders/orders.service';
import {NgForOf, NgIf} from "@angular/common";
import {RouterLink, RouterLinkActive} from "@angular/router";
import {AuthService} from "../../services/auth/auth.service";

@Component({
  selector: 'app-all-orders',
  standalone: true,
  imports: [
    NgForOf,
    NgIf,
    RouterLink,
    RouterLinkActive
  ],
  templateUrl: './all-orders.component.html',
  styleUrl: './all-orders.component.css'
})
export class AllOrdersComponent {
  authService = inject(AuthService);
  orders: any[] = [];

  constructor(private ordersService: OrdersService) {}

  ngOnInit() {
    this.loadOrders();
  }

  loadOrders() {
    this.ordersService.getAllOrders().subscribe({
      next: (orders) => {
        this.orders = orders;
      },
      error: (error) => console.error('Failed to load orders', error)
    });
  }

  deleteOrder(orderId: number) {
    this.ordersService.deleteOrder(orderId).subscribe({
      next: () => {
        console.log('Order deleted successfully');
        this.loadOrders(); // Refresh the list after deletion
      },
      error: (error) => console.error('Failed to delete order', error)
    });
  }
}
