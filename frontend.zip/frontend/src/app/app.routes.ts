import { Routes } from '@angular/router';
import { LoginComponent } from './pages/login/login.component';
import { SignupComponent } from './pages/signup/signup.component';
import { AdminComponent } from './pages/admin/admin.component';
import { HomeComponent } from './pages/home/home.component';
import { PicturesComponent } from "./pages/pictures/pictures.component";
import { ReviewsComponent } from "./pages/reviews/reviews.component";
import { authGuard } from './services/auth/auth.guard';
import {PostReviewComponent} from "./pages/post-review/post-review.component";
import {MakeOrderComponent} from "./pages/make-order/make-order.component";
import {AllOrdersComponent} from "./pages/all-orders/all-orders.component";
import {UploadImagesComponent} from "./pages/upload-images/upload-images.component";

export const routes: Routes = [
  {
    path: '', redirectTo: '/home', pathMatch: 'full'
  },
  {
    path: 'home', component: HomeComponent
  },
  {
  path: 'make-order', component: MakeOrderComponent
  },
  {
  path: 'all-orders', component: AllOrdersComponent
  },
  {
    path: 'pictures', component: PicturesComponent
  },
  {
  path: 'upload-images', component: UploadImagesComponent
  },
  {
    path: 'reviews', component: ReviewsComponent
  },
  {
    path: 'post-review', component: PostReviewComponent
  },
  {
    path: 'login', component: LoginComponent
  },
  {
    path: 'signup', component: SignupComponent
  },
  {
    path: 'admin', component: AdminComponent, canActivate: [authGuard]
  }
];
